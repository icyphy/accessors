#!/usr/bin/python
import rospy
from geometry_msgs.msg import Twist

TIMEOUT = 3.

cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
rospy.init_node('finite_pub_sub')

go = Twist()
go.linear.x = 0.5

stop = Twist()


while(1):
	print("starting to go")
	cmd_vel_pub.publish(go)
	rospy.sleep(TIMEOUT)
	print("STOP!")
	cmd_vel_pub.publish(stop)
	rospy.sleep(TIMEOUT)


	
